'''---------------------------------------
Title: Lab 5-2 Dictionary
Name: Anthony Larson
Date: 11/19/2018
Description: Working with Dictionaries
---------------------------------------'''

#1) Create an application that uses a dictionary to hold the following data
dicRow0 = {"ID":"1","NAME":"Bob Smith","EMAIL":"BSmith@Hotmail.com"}
dicRow1 = {"ID":"2","NAME":"Sue Jones","EMAIL":"SueJ@Yahoo.com"}
dicRow2 = {"ID":"3","NAME":"Joe James","EMAIL":"JoeJames@Gmail.com"}

dicTable = [dicRow0, dicRow1, dicRow2]
print(dicTable)

#2) Add code that lets users append a new row of data
#3 Add a loop that lets users keep adding rows.
while(True):
    intID = int(input("Enter an ID: "))
    strName = str(input("Enter a Name: "))
    strEmail = str(input("Enter an Email: "))
    lstNewRow = {"ID":intID, "NAME":strName, "EMAIL":strEmail}
    dicTable.append(lstNewRow)
    if(input("Do you want to enter a new row? (y/n)")) == ("y"):continue
    print(dicTable)
    if("n"):break

#4 Ask the user if they want to save the data to a file when they exit the loop.
#5 Save the data to a file if they say "yes".
strSaveFile = input("Do you want to save data to the file? (y/n): ")
if(strSaveFile == 'y'):
    print("Your data saved to file:", dicTable)
    DataFile = open("DictionaryDataTable.txt", 'w')
    DataFile.write(str(dicTable))
else:
    print("Data not saved")

