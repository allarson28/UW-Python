'''--------------------------------
Title: Lab 5-1 Lists
Name: Anthony Larson
Date: 11/19/2018
Description: Working with Lists
--------------------------------'''

#1) Create an application that uses a list to hold the following data:
lstRow0 = ["ID","NAME","EMAIL"]
lstRow1 = ["1","Bob Smith","BSmith@Hotmail.com"]
lstRow2 = ["2","Sue Jones","SueJ@Yahoo.com"]
listRow3 = ["3","Joe James","JoeJames@Gmail.com"]

lstTable = [lstRow0, lstRow1, lstRow2, listRow3]
print(lstTable)

#2) Add code that lets users append a new row of data
#intID = int(input("Enter an ID: "))
#strName = str(input("Enter a Name: "))
#strEmail = str(input("Enter an Email: "))
#lstNewRow = [intID, strName, strEmail]
#lstTable.append(lstNewRow)
#print(lstTable)

#3 Add a loop that lets users keep adding rows.
while(True):
    intID = int(input("Enter an ID: "))
    strName = str(input("Enter a Name: "))
    strEmail = str(input("Enter an Email: "))
    lstNewRow = [intID, strName, strEmail]
    lstTable.append(lstNewRow)
    if(input("Do you want to enter a new row? (y/n)")) == ("y"):continue
    print(lstTable)
    if("n"):break

#4 Ask the user if they want to save the data to a file when they exit the loop.
strSaveFile = input("Do you want to save data to the file? (y/n): ")
if(strSaveFile == 'y'):
    print("Your data saved to file:", lstTable)
    DataFile = open("TestDataTable.txt", 'w')
    DataFile.write(str(lstTable))
else:
    print("Data not saved")

#5 Save the data to a file if they say "yes".



