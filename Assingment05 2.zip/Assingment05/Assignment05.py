'''---------------------------------------------------------------
Title: Assingment 5
Dev: Anthony Larson
Date: 11/19/2018
Description: Create a to-do list that can be updated by the user.
Rev Description: New
----------------------------------------------------------------'''



#-- Data --#
# Declare variable and constraints
#dicTable = {i : lstOfint[i] for i in range(0, len(listOfStr))}

file = open("ToDo.txt" , "r")
d = {}
for line in file:
    x = line.strip().split(",")
    a = x[0]
    b = x[1]
    d[a] = b
    
'''
#-- Processing --#
# Perform tasks
# When the program starts, load each row of data from the ToDo.txt text file a into Python dictonary
'''


list = d.items()
print(list)

ans=True
while ans:
    print("""
    Menu of Options
    1) Show current data.
    2) Add a new item.
    3) Remove an existing line.
    4) Save data to file.
    5) Exit program
    """)
    ans = input("Please Select an Option")
    if ans == '1':
        print(list)
    elif ans == '2':
        task = input("Enter a new task: ")
        priority = input("Enter a priority: ")
        lstTable = {task : priority}
        d.update(lstTable)
        print(list)
    elif ans == '3':
        DeleteTask = input("Which item would you like to remove: ")
        for item in range(len(list)):
            if item == DeleteTask:
                del list[DeleteTask]
        print(list)
    elif ans == '4':
        objectFile = open("ToDo.txt", 'w')
        for item in d:
            objectFile.write(item['Task'] + "," + item['Priority'] + "\n")
            objectFile.close()
            print("List has been saved to the file ToDo.txt.")
    elif ans == '5':
        break


#-- Presentation (Input/Output) --#
# Get user input
# Sent program output
