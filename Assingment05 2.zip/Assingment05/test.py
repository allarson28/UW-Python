'''-------------------------------------
Title:
Dev: Anthony Larson
Date: 11/19/2018
Description:
Rev Description: New
-------------------------------------'''



#-- Data --#
# Declare variable and constraints
lstRow0 = ["Task","Priority"]
lstRow1 = ["Clean House","Low"]
lstRow2 = ["Pay Bills","High"]

lstTable = [lstRow0,lstRow1,lstRow2]
print(lstTable)

TASK, PRIORITY
Clean House, Low
Pay Bills, High

#-- Processing --#
# Perform tasks



#-- Presentation (Input/Output) --#
# Get user input

